#include <insituc/floating_point_type.hpp>

namespace insituc
{

#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wglobal-constructors"
#pragma clang diagnostic ignored "-Wexit-time-destructors"
G const zero = G(0);
G const one = G(1);
#pragma clang diagnostic pop

}
