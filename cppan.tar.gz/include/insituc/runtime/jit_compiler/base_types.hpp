#pragma once

#include <insituc/base_types.hpp>

#include <cstdint>

namespace insituc
{
namespace runtime
{

using byte_type = std::uint8_t;

}
}
