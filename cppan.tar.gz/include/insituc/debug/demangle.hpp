#pragma once

#include <string>

std::string
get_demangled_name(char const * const symbol) noexcept;
